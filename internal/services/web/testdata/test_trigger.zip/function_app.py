import logging
import json
import azure.functions as func

app = func.FunctionApp()


@app.function_name(name="EventRouter")
@app.event_grid_trigger(arg_name="event")
def event_router(event: func.EventGridEvent):
    result = json.dumps({
        'id': event.id,
        'data': event.get_json(),
        'topic': event.topic,
        'subject': event.subject,
        'event_type': event.event_type,
    })

    logging.info('EventRouter trigger processed an event: %s', result)
