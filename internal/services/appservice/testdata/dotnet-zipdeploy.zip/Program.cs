var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "Acceptance Test Working!!!");
app.MapGet("/index.html", () => "Acceptance Test Working!!!");

app.Run();
